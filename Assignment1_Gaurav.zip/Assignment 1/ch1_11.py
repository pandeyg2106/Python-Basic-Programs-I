### Chapter 1 Question 11
## Program to predict population

birth5 = (1/7)*60*60*24*365
death5 = (1/13)*60*60*24*365
immig5 = (1/45)*60*60*24*365

population1 = (312032486 + birth5 + immig5) - death5
population1 = population1//1

population2 = 2*((312032486 + birth5 + immig5) - death5)
population2 = population2//2

population3 = 3*((312032486 + birth5 + immig5) - death5)
population3 = population3//1

population4 = 4*((312032486 + birth5 + immig5) - death5)
population4 = population4//1

population5 = (312032486 + birth5 + immig5) - death5
population5 = population5//1

print("Estimated population after 1 years is",population1,"\nEstimated population after 2 years is",population2,"\nEstimated population after 3 years is",population3,"\nEstimated population after 4 years is",population4,"\nEstimated population after 5 years is",population5)