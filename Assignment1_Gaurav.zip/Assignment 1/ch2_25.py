### Chapter 2 Question 25
## Program to draw rectangle

import turtle
x1,y1 = eval(input("Enter the centre coordinates of rectangle: "))
w = eval(input("Enter the width of rectangle: "))
h = eval(input("Enter the height of the rectangle: "))
turtle.color("blue")
turtle.penup()
turtle.goto(x1,y1/2)
turtle.pendown()
turtle.forward(w/2)
turtle.left(90)
turtle.forward(h)
turtle.left(90)
turtle.forward(w)
turtle.left(90)
turtle.forward(h)
turtle.left(90)
turtle.forward(w/2)
turtle.penup()
turtle.hideturtle()
turtle.done()