### Chapter 2 Question 7
## Program to years days from minutes

min = eval(input("Enter number of minutes: "))

total_days = min/(60*24)

total_years = min / (60*24*365)

years = int(total_years)

days = total_years - years
days = int(days*365)

print(min,"minutes is approximately",years,"years and",days,"days")