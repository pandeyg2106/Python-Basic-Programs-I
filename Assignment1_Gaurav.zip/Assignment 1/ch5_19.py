'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 19
## Program to print number pyramid

num = eval(input("Enter any number between 1 to 15: "))

for i in range(1,num+1,+1):
    if i!=1:
        print("")
    for j in range(num,0,-1):
        if j>i:
            print("   ",end='')
        else:
            print(format(j,"3d"),end='')
    for k in range(1, num+1,+1):
        if k<=i:
            if k!=1:
                print(format(k,"3d"),end='')