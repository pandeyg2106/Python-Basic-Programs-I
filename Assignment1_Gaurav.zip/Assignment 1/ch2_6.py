### Chapter 2 Question 6
## Program to print sum of digits

numb = eval(input("Enter a number between 0 and 1000: "))

temp = numb
sum = 0

a = temp%10
sum = sum + a
temp = temp//10

a = temp%10
sum = sum + a
temp = temp//10

a = temp%10
sum = sum + a
temp = temp//10

a = temp%10
sum = sum + a
temp = temp//10

print("The sum of digits is",sum)