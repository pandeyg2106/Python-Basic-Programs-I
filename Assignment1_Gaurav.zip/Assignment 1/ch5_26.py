'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 26
## Program to print series
sum = 0
b = 3
for i in range(1,98,+2):
    a = i/b
    b = b+2
    sum = sum + a
print("The sum of series is:",round(sum,2))