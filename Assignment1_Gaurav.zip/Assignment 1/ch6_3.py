'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 3
## Program to write reverse and plaindrome functions

def reverse(n):
    reverse = 0
    while n>0:
        reverse = reverse*10
        reverse = reverse + n%10
        n = n//10
    return reverse

def palindrome(n):
    palindrome = reverse(n)
    if n == palindrome:
        print("The number is a palindrome")
    else:
        print("The number is not a palindrome")
        
        
def main():
    n = eval(input("Enter any number: "))  
    print("The reverse of the number is: ",reverse(n))
    palindrome(n)
    
main()