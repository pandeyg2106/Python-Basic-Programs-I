'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 36
## Program to play Rock Scissor and Paper

import random
p = 0
c = 0
while ((p<2) and (c<2)):
    player = False
    while player==False:
        b = random.randint(0,2)
        if b == 0:
            comp = ('Rock')
        elif b==1:
            comp = ('Scissor')
        elif b==2:
            comp = ('Paper')
        player = input("Select from Rock, Paper or Scissor: ")
        if player == comp:
            print("Its a Tie!")
        elif player == "Rock":
            if comp == "Paper":
                print("You Loose!",comp,"covers",player)
                c += 1
            else:
                print("You Win!",player,"smashes",comp)
                p += 1
        elif player == "Paper":
            if comp == "Scissor":
                print("You Loose!",comp,"cuts",player)
                c += 1
            else:
                print("You Win!",player,"covers",comp)
                p += 1
        elif player == "Scissor":
            if comp == "Paper":
                print("You Win!",player,"cuts",comp)
                p += 1
            else:
                print("You Loose!",comp,"crushes",player)
                c += 1
        else:
            print("You might need to check the spelling. It is case sensitive!")
if p==2:
    print("You are the Champion! Thank You for playing.")
elif c == 2:
    print("You are a Looser! Thank You for playing.")