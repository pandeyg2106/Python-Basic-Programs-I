'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 11
## Program to find highest and second highest score

n = eval(input("Enter the number of students: "))
sh = 0
hs = 0
for i in range(0,n):
    s = eval(input("Enter student "+ str(i+1)+" score: "))
    if s>=hs:
        sh = hs
        hs = s
    elif((s>=sh) and (s<hs)):
        sh = s
    i +=1
print("Highest score is",hs,"and second highest score is",sh)