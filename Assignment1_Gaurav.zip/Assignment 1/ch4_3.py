'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 3
## Program to solve linear equation with 2 variables

print("Equation 1")

#Take values of coefficients for equation 1

a = eval(input("Enter the value of x coefficient: "))
b = eval(input("Enter the value of y coefficient: "))
e = eval(input("Enter the value of constant for equation 1: "))

print("Equation 2")

#Take values of coefficients for equation 2

c = eval(input("Enter the value of x coefficient: "))
d = eval(input("Enter the value of y coefficient: "))
f = eval(input("Enter the value of constant for equation 2: "))

#Checking special condition

if ((a*d)-(b*c)) == 0:
    print("The equation has no solution")

#Calculation of x and y
else:
    x = ((e*d)-(b*f))/((a*d)-(b*c))
    y = ((a*f)-(e*c))/((a*d)-(b*c))
    print("Value of x is:",round(x,2),"\nValue of y is:",round(y,2))