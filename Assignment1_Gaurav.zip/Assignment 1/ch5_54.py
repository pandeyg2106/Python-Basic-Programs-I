'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 54
## Program to draw f(x)=x*x

import turtle
turtle.penup()
turtle.goto(-250,0)
turtle.pendown()
turtle.goto(250,0)
turtle.penup()
turtle.goto(0,-250)
turtle.pendown()
turtle.goto(0,250)
turtle.penup()
turtle.goto(-100,-15)
for x in range(-10,11,+1):
    turtle.goto(x,(x*x))
    turtle.pendown()

turtle.done()