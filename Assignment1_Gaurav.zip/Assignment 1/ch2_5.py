### Chapter 2 Question 5
## Program to print gratuity and total amount

subtotal = eval(input("Enter the subtotal amount: "))
gr =  eval(input("Enter the gratuity rate: "))

gratuity = (subtotal*gr)/100

total = subtotal + gratuity

print("The gratuity is",gratuity,"% and the total is",total)