'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 5
## Program to find future day



print("Sunday: 0\tMonday: 1\tTuesday: 2\tWednesday: 3\tThursday: 4\tFriday: 5\tSaturday: 6\n")

#Take User Inputs

a = eval(input("Enter the number corresponding to current day, as per the information shown above: "))
b = eval(input("Enter the number of days elapsed since today: "))

#Computation

if a==0:
    cd = ('Sunday')
elif a==1:
    cd = ('Monday')
elif a==2:
    cd = ('Tuesday')
elif a==3:
    cd = ('Wednesday')
elif a==4:
    cd = ('Thursday')
elif a==5:
    cd = ('Friday')
elif a==6:
    cd = ('Saturday')

c = a + b
if c<7:
    if c == 0:
        fd = ('Sunday')
    elif c==1:
        fd = ('Monday')
    elif c==2:
        fd = ('Tuesday')
    elif c==3:
        fd = ('Wednesday')
    elif c==4:
        fd = ('Thursday')
    elif c==5:
        fd = ('Friday')
    elif c==6:
        fd = ('Saturday')
     
    print("Today is",cd,"and the future day is",fd)

else:
    fdn = c%7
    if fdn==1:
        fd = ('Monday')
    elif fdn==2:
        fd = ('Tuesday')
    elif fdn==3:
        fd = ('Wednesday')
    elif fdn==4:
        fd = ('Thursday')
    elif fdn==5:
        fd = ('Friday')
    elif fdn==6:
        fd = ('Saturday') 

print("Today is",cd,"and the future day is",fd)