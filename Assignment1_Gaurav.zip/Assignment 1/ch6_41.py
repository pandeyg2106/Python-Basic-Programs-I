'''
Created on Feb 5, 2017

@author: pande
'''
import turtle
import random
# Draw a point at the specified location (x, y)
def drawPoint(x, y):
    turtle.penup()  # Pull the pen up
    turtle.goto(x, y)
    turtle.pendown()  # Pull the pen down
    turtle.begin_fill()
    turtle.color("red")  # Begin to fill color in a shape
    turtle.circle(2)
    turtle.end_fill()  # Fill the shape
 
def fillCircle(x , y , radius):
    turtle.pensize(1.2)
    turtle.color("lemonchiffon")
    turtle.penup()  # Pull the pen up
    turtle.goto(x, y - radius)
    turtle.begin_fill()
    turtle.pendown()  # Pull the pen down
    turtle.circle(radius)
    turtle.end_fill()
    turtle.penup()
    turtle.color("black")
    turtle.goto(x, y - radius)
    turtle.pendown()
    turtle.circle(radius)
    count = 0
    while(count < 10):
        x1 = random.randint(x - radius, x + radius)
        y1 = random.randint(y - radius, y + radius)
        if((((x - x1) ** 2 + (y - y1) ** 2) ** .5) < radius):
            drawPoint(x1, y1)
            count += 1
 
 # Draw a rectangle at (x, y) with the specified width and height
def filRectangle(x , y , width , height):
    turtle.pensize(1.2)
    turtle.color("lemonchiffon")
    turtle.penup()  # Pull the pen up
    turtle.goto(x + width / 2, y + height / 2)
    turtle.begin_fill()
    turtle.pendown()  
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    turtle.end_fill()
    turtle.penup()
    turtle.color("black")
    turtle.goto(x + width / 2, y + height / 2)
    turtle.pendown()  
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    count = 0
    while(count < 10):
        x1 = random.randint(x - width / 2, x + width / 2)
        y1 = random.randint(y - height / 2, y + height / 2)
        drawPoint(x1, y1)
        count += 1
def main():
    fillCircle(100, 0, 100)
    filRectangle(-200, 0, 200, 100)
    turtle.hideturtle()
    turtle.done()
main()
