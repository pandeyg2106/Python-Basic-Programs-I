### Chapter 3 Question 11
## Program to print reverse of a 4 digit number

num = eval(input("Enter a 4 digit number: "))

a = num//1000           #first number
rem1 = num%1000
b = rem1//100           #second number
rem2 = rem1%100
c = rem2//10             #third number
d = rem2%10             #fourth number

print("The reversed number is: ",d,end='')
print(c,end='')
print(b,end='')
print(a,end='')