### Chapter 1 Question 18
## Program to draw a star

import turtle
turtle.color("pink")
turtle.penup()
turtle.goto(0,300)
turtle.pendown()
turtle.begin_fill()
turtle.right(72)
turtle.forward(500)
turtle.right(144)
turtle.forward(500)
turtle.right(144)
turtle.forward(500)
turtle.right(144)
turtle.forward(500)
turtle.right(144)
turtle.forward(500)
turtle.end_fill()
    
turtle.done()