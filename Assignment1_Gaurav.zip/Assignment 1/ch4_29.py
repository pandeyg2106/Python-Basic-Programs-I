'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 29
## Program to Measure if 2 circle overlaps or not

x1,y1,r1 = eval(input("Enter circle 1's center x,y coordinates, and radius: "))
x2,y2,r2 = eval(input("Enter circle 2's center x,y coordinates, and radius: "))

d = ((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))**0.5
if d<= abs(r1-r2):
    print("Circle 2 is inside Circle 1")
elif d<= r1+r2:
    print("Circle 2 overlaps Circle 1")
else:
    print("Circle 2 is outside Circle 1")