'''
Created on Feb 5, 2017

@author: pande
'''
#UML
#Time()
#_hr:int
#_min:int
#_sec:int
#getHr():int
#getMin():int
#getSec():int
#setTime(etime:int):None

from datetime import datetime
class Time:
    def __init__(self):
        t=datetime.now()    
        self.__hr= t.hour
        self.__min=t.minute
        self.__sec=t.second
    
    def getHr(self):
        return self.__hr
    def getMin(self):
        return self.__min
    def getSec(self):
        return self.__sec    
    def setHr(self,hr):
        self.__hr=hr
    def setMin(self,min):
        self.__min=min
    def setSec(self,sec):
        self.__sec=sec  
    def setTime(self,etime):
        tval=int(etime)
        sec=tval%60
        x=tval//3600
        hr=x%24
        y=tval%3600
        min=y//60
        self.__hr=((x))%24
        self.__sec=sec
        self.__min=min   
  #from Time import Time 
def main():
    t1=Time()
    print("Current time is:",t1.getHr(),":",t1.getMin(),":",t1.getSec())
    etime=eval(input("Enter the elapsed time:"))
    t1.setTime(etime)
    print("The hour:minute:second for the elapsed time is:",t1.getHr(),":",t1.getMin(),":",t1.getSec())
main()