'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 9
## Program to print 10 years tution fee

tution = 10000
for i in range(1,11):
    tution = tution*1.05
    i +=1
print("The total tution fee in 10 years would be: ",round(tution,2))

sum = 0
for j in range(1,5):
    tution = tution*1.05
    sum = tution + sum
    j +=1
print("Four years of tution fee 10 years from now will be: ",round(sum,2))