#UML
#Account
#_id:int
#_balance:float
#_annualInterestRate:float
#Account(id=0:int,balance=100:float,annualInterestRate=0:float)
#getID():int
#getBalance():float
#getAnnualInterestRate():float
#setID(id:int):None
#setBalance(balance:float):None
#setAnnualInterestRate(annualInterestRate:float):None
#getMonthlyInterestRate():float
#getMonthlyInterest():float
#withdraw(amt:float):None
#deposit(amt:float):None

class Account:
    def __init__(self,id=0,balance=100,annualInterestRate=0):
        self.__id=id
        self.__balance=balance
        self.__annualInterestRate=annualInterestRate
    def getAnnualInterestRate(self):
        return self.__annualInterestRate
    def getID(self):
        return self.__id
    def getBalance(self):
        return self.__balance
    def setID(self,id):
        self.__id=id
    def setBalance(self,balance):
        self.__balance=balance
    def setAnnualInterestRate(self,annualInterestRate):
        self.__annualInterestRate=annualInterestRate
    def getMonthlyInterestRate(self):
        return round((self.__annualInterestRate/12)*100)/100
    def getMonthlyInterest(self):
        return (round((self.__balance*(self.getMonthlyInterestRate()/100))*100)/100)
    def withdraw(self,amt):
        self.__balance=self.__balance-amt
    def deposit(self,amt):
        self.__balance=self.__balance+amt
#import Account
def main():
    a1=Account(1122,20000,4.5)
    a1.withdraw(2500)
    a1.deposit(3000)
    print("ID ",format(a1.getID(),"25d"),"\nbalance ",format(a1.getBalance(),"20d"),"\nmonthly interest rate ",format(a1.getMonthlyInterestRate(),"6.2f"),"\nand monthly interest",format(a1.getMonthlyInterest(),"8.2f"))
main()