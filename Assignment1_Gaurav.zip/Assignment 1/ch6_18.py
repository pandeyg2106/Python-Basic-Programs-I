'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 18
## Program to print nxn matrix

def printMatrix(n):
    import random
    
    i = 0
    count = 0
    while i<(n*n):
        a = random.randint(0,1)
        print(a,end=" ")
        count += 1
        i += 1
        if count>n-1:
            print()
            count = 0            
def main():
    n = eval(input("Enter the matrix length: "))
    printMatrix(n)

main()