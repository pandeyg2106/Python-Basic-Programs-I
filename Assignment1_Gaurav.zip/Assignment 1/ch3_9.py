### Chapter 3 Question 9
## Program for payroll statement

name = (input("Enter the employee's name: "))
hours = eval(input("Enter the number of hours worked per week: "))
hpr = eval(input("Enter the hourly pay rate: $"))
ftax = eval(input("Enter the federal tax withholding rate: "))
stax = eval(input("Enter the state tax withholding rate: "))

print("Employee Name:",name)
print("Hours Worked:",hours)
print("Pay Rate:",hpr)

GP = hours*hpr
print("Gross Pay:",GP)
print("Deductions:")
fd = GP*ftax
print("\tFederal withholding(",format(ftax,"5.1%"),": $",fd)
sd = GP*stax
print("\tState withholding",format(stax,"5.1%"),": $",sd)
td = fd + sd
print("\tTotal Deductions: $",sd)
np = GP - td
print("Net Pay: $",np)