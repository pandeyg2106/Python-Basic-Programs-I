'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 29
## Program to validate credit card number

def getsize(num):
    count = 0
    while num>0:
        d = num % 10
        count += 1
        num = num//10
    if ((count>=13) or (count<=16)):
        return True
    else:
        return False

def prefixMatched(num):
    while num>0:
        d = num % 10
        num = num//10
        if num == 37:
            return True
    if d == 4:
        return True
    elif d == 5:
        return True
    elif d ==6:
        return True
    else:
        return False

def getprefix(num):
    while num>0:
        d = num % 10
        num = num//10
        if num == 37:
            card_type = ('American Express')
            return card_type
    if d == 4:
        card_type = ('Visa')
        return card_type
    elif d == 5:
        card_type = ('Mastercard')
        return card_type
    elif d ==6:
        card_type = ('Discover')
        return card_type
        
def getdigit(num):
    temp = num
    sum = 0
    while temp!=0:
        temp = temp//10
        temp1 = temp%10
        temp = temp//10
        temp1 = temp1*2
        if temp1>9:
            temp4 = temp1%10
            temp2 = temp1//10
            even_digit = temp4 + temp2
            sum = sum + even_digit
        else:
            sum = sum + temp1
    return sum

def sumofDoubleEvenPlace(num):
    sum_even = getdigit(num)
    return (sum_even)

def sumofOddPlace(num):
    sum_odd = 0
    temp3 = num
    while temp3!=0:
        sum_odd += temp3%10
        temp3 = temp3//100
    return sum_odd

def isValid(num):
    chksum = sumofDoubleEvenPlace(num) + sumofOddPlace(num)
    if chksum % 10 == 0:
        return True
    else:
        return False
    

def main():
    num = eval(input("Enter the Credit Card number: "))
    if getsize(num):
        if prefixMatched(num):
            if isValid(num):
                print("Your",getprefix(num),"card is valid")
            else:
                print("Your card is invalid, checksum error")
        else:
            print("Invalid Card.")
    else:
        print("Invalid card. Check card number length.")
            
main()