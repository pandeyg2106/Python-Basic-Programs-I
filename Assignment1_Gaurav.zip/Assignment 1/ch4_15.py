'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 15
## Lottery 3 digits

import random
a = random.randint(0,9)
b = random.randint(0,9)
c = random.randint(0,9)
num = eval(input("Enter a three digit number and check your luck: "))

num1 = num//100
temp = num%100
num2 = temp//10
num3 = temp%10

print("The Lottery number is",a,b,c)
if num1==a and num2==b and num3==c:
    print("Perfect match! You won $10000")

elif ((num1==a or num1==b or num1==c) and (num2==a or num2==b or num2==c) and (num3==a or num3==b or num3==c)):
    print("Correct numbers! You won $3000")

elif num1 == a:
    if ((num2!=a or num2!=b or num2!=c) and (num3!=a or num3!=b or num3!=c)):
        print("One number matched! You won $1000")

    elif num2 == a:
        if ((num1!=a or num1!=b or num1!=c) and (num3!=a or num3!=b or num3!=c)):
            print("One number matched! You won $1000")
    
    elif num3 == a:
        if ((num1!=a or num1!=b or num1!=c) and (num2!=a or num2!=b or num2!=c)):
            print("One number matched! You won $1000")

elif num1 == b:
    if ((num2!=a or num2!=b or num2!=c) and (num3!=a or num3!=b or num3!=c)):
        print("One number matched! You won $1000")

    elif num2 == b:
        if ((num1!=a or num1!=b or num1!=c) and (num3!=a or num3!=b or num3!=c)):
            print("One number matched! You won $1000")
    
    elif num3 == b:
        if ((num1!=a or num1!=b or num1!=c) and (num2!=a or num2!=b or num2!=c)):
            print("One number matched! You won $1000")

elif num1 == c:
    if ((num2!=a or num2!=b or num2!=c) and (num3!=a or num3!=b or num3!=c)):
        print("One number matched! You won $1000")

    elif num2 == c:
        if ((num1!=a or num1!=b or num1!=c) and (num3!=a or num3!=b or num3!=c)):
            print("One number matched! You won $1000")
    
    elif num3 == c:
        if ((num1!=a or num1!=b or num1!=c) and (num2!=a or num2!=b or num2!=c)):
            print("One number matched! You won $1000")

else:
    print("You are unlucky and you know it!")