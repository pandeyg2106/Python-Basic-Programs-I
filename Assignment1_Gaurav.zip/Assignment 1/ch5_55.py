'''
Created on Feb 5, 2017

@author: pande
'''
# ## Chapter 5 Question 55
# # Program to draw chessboard

import turtle
turtle.pensize(3)
turtle.penup()
# # main square
turtle.goto(-300, 300)
turtle.pendown()
turtle.forward(600)
turtle.right(90)
turtle.forward(600)
turtle.right(90)
turtle.forward(600)
turtle.right(90)
turtle.forward(600)
turtle.right(90)
turtle.penup()

x, y = -300, -300
row = 0
while y != 300:
    if row % 2 == 0:
        x = -225
    else:
        x = -300
    turtle.goto(x, y)
    count = 0
    while count < 4:
        turtle.pendown()
        turtle.begin_fill()
        turtle.forward(75)
        turtle.left(90)
        turtle.forward(75)
        turtle.left(90)
        turtle.forward(75)
        turtle.left(90)    
        turtle.forward(75)
        turtle.left(90)
        turtle.end_fill()
        turtle.penup()
        turtle.forward(150)
        count = count + 1
    row +=1
    y = y+75
turtle.hideturtle()
turtle.done()
