'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 10
## Program to print 1000 prime numbers

def isPrime(number):
    d = 2
    while d <= number / 2:
        if number % d == 0:
            return False # number is not a prime
            d += 1
        return True
def countPrimes(n):
    count=0
    for i in range(2,n):
        if(isPrime(i)):
            count+=1
    return count
def main():
    print("The number of prime numbers less than 10,000 is",countPrimes(10000))
main()