'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 30
## Program to print first day of each month for a given year

year = eval(input("Enter the year: "))
day = eval(input("Enter the number equivalent of day (where Sudayay being 0 and Saturday being 6): "))
if day>6:
    day = day%7
if day==0:
    fd = ('Sunday')
elif day==1:
    fd = ('Monday')
elif day==2:
    fd = ('Tuesday')
elif day==3:
    fd = ('Wednesday')
elif day==4:
    fd = ('Thursday')
elif day==5:
    fd = ('Friday')
elif day==6:
    fd = ('Saturday')
print("January 1,",year,"is",fd)
month = 1
if month==1:
    day1 = day + 3
    if day1>6:
        day1 = day1%7
    if day1==0:
        fd = ('Sunday')
    elif day1==1:
        fd = ('Monday')
    elif day1==2:
        fd = ('Tuesday')
    elif day1==3:
        fd = ('Wednesday')
    elif day1==4:
        fd = ('Thursday')
    elif day1==5:
        fd = ('Friday')
    elif day1==6:
        fd = ('Saturday')
    print("February 1,",year,"is",fd)
month +=1
if ((month==2) and (year%4==0)):
    day2 = day1 + 1
    if day2>6:
        day2 = day2%7
    if day2==0:
        fd = ('Sunday')
    elif day2==1:
        fd = ('Monday')
    elif day2==2:
        fd = ('Tuesday')
    elif fd==3:
        day2 = ('Wednesday')
    elif fd==4:
        day2 = ('Thursday')
    elif fd==5:
        fd = ('Friday')
    elif day2==6:
        fd = ('Saturday')
    print("March 1,",year,"is",fd)
elif ((month==2) and (year%4!=0)):
    day2 = day1 + 0
    if day2>6:
        day2 = day2%7
    if day2==0:
        fd = ('Sunday')
    elif day2==1:
        fd = ('Monday')
    elif day2==2:
        fd = ('Tuesday')
    elif day2==3:
        fd = ('Wednesday')
    elif day2==4:
        fd = ('Thursday')
    elif day2==5:
        fd = ('Friday')
    elif day2==6:
        fd = ('Saturday')
    print("March 1,",year,"is",fd)
month +=1
if month==3:
    day3 = day2 + 3
    if day3>6:
        day3 = day3%7
    if day3==0:
        fd = ('Sunday')
    elif day3==1:
        fd = ('Monday')
    elif day3==2:
        fd = ('Tuesday')
    elif day3==3:
        fd = ('Wednesday')
    elif day3==4:
        fd = ('Thursday')
    elif day3==5:
        fd = ('Friday')
    elif day3==6:
        fd = ('Saturday')
    print("April 1,",year,"is",fd)
month +=1
if month==4:
    day4 = day3 + 2
    if day4>6:
        day4 = day4%7
    if day4==0:
        fd = ('Sunday')
    elif day4==1:
        fd = ('Monday')
    elif day4==2:
        fd = ('Tuesday')
    elif day4==3:
        fd = ('Wednesday')
    elif day4==4:
        fd = ('Thursday')
    elif day4==5:
        fd = ('Friday')
    elif day4==6:
        fd = ('Saturday')
    print("May 1,",year,"is",fd)
month +=1
if month==5:
    day5 = day4 + 3
    if day5>6:
        day5 = day5%7
    if day5==0:
        fd = ('Sunday')
    elif day5==1:
        fd = ('Monday')
    elif day5==2:
        fd = ('Tuesday')
    elif day5==3:
        fd = ('Wednesday')
    elif day5==4:
        fd = ('Thursday')
    elif day5==5:
        fd = ('Friday')
    elif day5==6:
        fd = ('Saturday')
    print("June 1,",year,"is",fd)
month +=1
if month==6:
    day6 = day5 + 2
    if day6>6:
        day6 = day6%7
    if day6==0:
        fd = ('Sunday')
    elif day6==1:
        fd = ('Monday')
    elif day6==2:
        fd = ('Tuesday')
    elif day6==3:
        fd = ('Wednesday')
    elif day6==4:
        fd = ('Thursday')
    elif day6==5:
        fd = ('Friday')
    elif day6==6:
        fd = ('Saturday')
    print("July 1,",year,"is",fd)
month +=1
if month==7:
    day7 = day6 + 3
    if day7>6:
        day7 = day7%7
    if day7==0:
        fd = ('Sunday')
    elif day7==1:
        fd = ('Monday')
    elif day7==2:
        fd = ('Tuesday')
    elif day7==3:
        fd = ('Wednesday')
    elif day7==4:
        fd = ('Thursday')
    elif day7==5:
        fd = ('Friday')
    elif day7==6:
        fd = ('Saturday')
    print("August 1,",year,"is",fd)    
month +=1
if month==8:
    day8 = day7 + 3
    if day8>6:
        day8 = day8%7
    if day8==0:
        fd = ('Sunday')
    elif day8==1:
        fd = ('Monday')
    elif day8==2:
        fd = ('Tuesday')
    elif day8==3:
        fd = ('Wednesday')
    elif day8==4:
        fd = ('Thursday')
    elif day8==5:
        fd = ('Friday')
    elif day8==6:
        fd = ('Saturday')
    print("September 1,",year,"is",fd)        
month +=1
if month==9:
    day9 = day8 + 2
    if day9>6:
        day9 = day9%7
    if day9==0:
        fd = ('Sunday')
    elif day9==1:
        fd = ('Monday')
    elif day9==2:
        fd = ('Tuesday')
    elif day9==3:
        fd = ('Wednesday')
    elif day9==4:
        fd = ('Thursday')
    elif day9==5:
        fd = ('Friday')
    elif day9==6:
        fd = ('Saturday')
    print("October 1,",year,"is",fd) 
month +=1
if month==10:
    day10 = day9 + 3
    if day10>6:
        day10 = day10%7
    if day10==0:
        fd = ('Sunday')
    elif day10==1:
        fd = ('Monday')
    elif day10==2:
        fd = ('Tuesday')
    elif day10==3:
        fd = ('Wednesday')
    elif day10==4:
        fd = ('Thursday')
    elif day10==5:
        fd = ('Friday')
    elif day10==6:
        fd = ('Saturday')
    print("November 1,",year,"is",fd)        
month +=1
if month==11:
    day11 = day10 + 2
    if day11>6:
        day11 = day11%7
    if day11==0:
        fd = ('Sunday')
    elif day11==1:
        fd = ('Monday')
    elif day11==2:
        fd = ('Tuesday')
    elif day11==3:
        fd = ('Wednesday')
    elif day11==4:
        fd = ('Thursday')
    elif day11==5:
        fd = ('Friday')
    elif day11==6:
        fd = ('Saturday')
    print("December 1,",year,"is",fd)
