'''
Created on Feb 5, 2017

@author: pande
'''
#UML
#RegularPolygon
#_n:int
#_side:float
#_x:float
#_y:float
#RegularPolygon(n=3:int,side=1:float,x=0:float, y=0:float)
#getX():float
#getY():float
#getN():int
#getSide():float
#setX(x:float):None
#setY(y:float):None
#setN(n:int):None
#setSide(side:float):None
#getPerimeter():float
#getArea():float

import math
class RegularPolygon:
    def __init__(self,n=3,side=1,x=0,y=0):
        self.__n=n
        self.__side=side
        self.__x=x
        self.__y=y
    def getX(self):
        return self.__x
    def getN(self):
        return self.__n
    def getSide(self):
        return self.__side
    def getY(self):
        return self.__y
    def setX(self,x):
        self.__x=x
    def setY(self,y):
        self.__y=y
    def setN(self,n):
        self.__n=n
    def setSide(self,side):
        self.__side=side
    def getParameter(self):
        return self.__side*self.__n
    def getArea(self):
        return round(((self.__n*self.__side*self.__side)/(4*math.tan(math.radians(180/self.__n))))*100)/100
#from RegularPolygon import RegularPolygon 
def main():
    p1=RegularPolygon()
    p2=RegularPolygon(6, 4)
    p3=RegularPolygon(10, 4, 5.6, 7.8)
    print(" perimeter and area for polygon 1 :",p1.getParameter()," ",format(p1.getArea(),"7.2f"),"\n",
    "perimeter and area for polygon 2 :",p2.getParameter()," ",format(p2.getArea(),"6.2f"),"\n",
    "perimeter and area for polygon 3 :",p3.getParameter()," ",p3.getArea())
main()