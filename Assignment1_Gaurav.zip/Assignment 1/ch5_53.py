'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 5 Question 53
## Program to draw line and write coordinates

import turtle
import math
turtle.penup()
turtle.goto(-250,0)
turtle.pendown()
turtle.goto(250,0)
turtle.penup()
turtle.goto(-100,-15)
turtle.pendown()
turtle.write(("-2\u03c0"), font=("Arial",
8, "normal"))
turtle.penup()
turtle.goto(0,0)
turtle.pendown()
turtle.write("(0,0)", font=("Arial",
8, "normal"))
turtle.penup()
turtle.goto(100,-15)
turtle.pendown()
turtle.write(("2\u03c0"), font=("Arial",
8, "normal"))
turtle.penup()
turtle.goto(0,-250)
turtle.pendown()
turtle.goto(0,250)
turtle.penup()
for x in range(-175, 176):
    turtle.goto(x, 50 * math.sin((x / 100) * 2 * math.pi))
    turtle.color("red")
    turtle.pendown()
turtle.penup()
for x in range(-175, 176):
    turtle.goto(x, 50 * math.cos((x / 100) * 2 * math.pi))
    turtle.color("blue")
    turtle.pendown()
turtle.penup()
turtle.hideturtle()
turtle.done()