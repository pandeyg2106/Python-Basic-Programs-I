'''
Created on Feb 5, 2017

@author: pande
'''
#UML
#LinearEquation
#_a:int
#_b:float
#_c:float
#_d:float
#_e:float
#_f:float
#LinearEquation (a :float, b :float, c :float, d :float, e :float, f :float)
#getA():float
#getB():float
#getC():int
#getD():float
#getE():float
#getF():float
#determinant():float
#isSolvable():boolean
#getX():float
#getY():float

class LinearEquation:
    def __init__(self,a, b, c, d, e, f):
        self.__a=a
        self.__b=b
        self.__c=c
        self.__d=d 
        self.__e=e 
        self.__f=f
    def getA(self):
        return self.__a
    def getB(self):
        return self.__b
    def getC(self):
        return self.__c
    def getD(self):
        return self.__d 
    def getE(self):
        return self.__e 
    def getF(self):
        return self.__f 
    def determinant(self):
        return ((self.__a*self.__d )- (self.__b*self.__c))
    def isSolvable(self):
        if(self.determinant()!=0):
            return True
        else:
            return False
    def getX(self):
        return(((self.__e*self.__d )- (self.__b*self.__f))/self.determinant())
    def getY(self):
        return(((self.__a*self.__f )- (self.__e*self.__c))/self.determinant())  
def main():
    a,b,e = eval(input("Enter the x, y coefficients and constant for equation 1: "))
    c,d,f = eval(input("Enter the x,y coefficients and constant for equation 2: "))
    l=LinearEquation(a,b,c,d,e,f)
    if(l.isSolvable()):
        print ("Solution is: \n X= ",l.getX(),"\n Y= ",l.getY(),"\n")
    else:
        print("The equation has no solution")
main()