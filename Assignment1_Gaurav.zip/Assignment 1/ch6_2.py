'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 2
## Program to write function calculating sum of digits

def sumdigits(n):
    sum = 0
    while n>0:
        digit = n%10
        sum = sum + digit
        n = n//10
    return sum

def main():
    n = eval(input("Enter any number: "))  
    print("The sum of digits is: ",sumdigits(n))
    
main()