'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 24
## Program to pick a card

import random
a = random.randint(0,3)
b = random.randint(1,13)

#selecting suit of card
if a==0:
    suit = ('Spades')
elif a==1:
    suit = ('Hearts')
elif a==2:
    suit = ('Diamonds')
elif a==3:
    suit = ('Clubs')
#selecting rank of card    
if b==1:
    rank = ('Ace')
elif b==2:
    rank = ('2')
elif b==3:
    rank = ('3')
elif b==4:
    rank = ('4')
elif b==5:
    rank = ('5')
elif b==6:
    rank = ('6')
elif b==7:
    rank = ('7')
elif b==8:
    rank = ('8')
elif b==9:
    rank = ('9')
elif b==10:
    rank = ('10')
elif b==11:
    rank = ('Jack') 
elif b==12:
    rank = ('Queen') 
elif b==13:
    rank = ('King')  

print("The card you picked is the",rank,"of",suit)