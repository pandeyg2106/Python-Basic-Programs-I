### Chapter 2 Question 21
## Program to find compound value

amount = eval(input("Enter the monthly saving amount: "))

rate = 0.00417

year1 = amount*(1+rate)

year2 = (amount+year1)*(1+rate)
year3 = (amount+year2)*(1+rate)
year4 = (amount+year3)*(1+rate)
year5 = (amount+year4)*(1+rate)

year6 = (amount+year5)*(1+rate)

print("After the sixth month the account value is",round(year6,2))