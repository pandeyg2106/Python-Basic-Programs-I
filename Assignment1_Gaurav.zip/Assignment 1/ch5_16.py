'''
Created on Feb 5, 2017

@author: pande
'''
n1,n2=(int(a) for a in input("enter two numbers:").split(','))
d=n2 if (n1 > n2) else n1
gcd=1
while(d!=1):
  if(n1%d==0 and n2%d==0):
    gcd=d 
    break;
  d-=1 
print("Greatest common divisor for", n1,"and",n2,"is: ",gcd)