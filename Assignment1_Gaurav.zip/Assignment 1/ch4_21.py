'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 4 Question 21
## Program to Calculate day of the week (Zellers Congruence)

print("Saturday:0\t Sunday:1\t Monday:2\t Tuesday:3\t Wednesday:4\t Thursday:5\t Friday:6")
print("March:3 April:4 ...December:12). January and February are counted as months 13 and 14 of the previous year.\n")

#Taking User Inputs
yr = eval(input("Enter the year (yyyy): "))
m = eval(input("Enter Month (1-12): "))
q = eval(input("Enter the day of the month (1-31): "))

#computing year and century and month
j = yr//100
k = yr%100

#Computing day
if m==1:
    m+=12
    k = k-1
    h = int(((q + ((26*(m+1))/10) + k + (k/4) + (j/4) + (5*j))%7))
    if h==0:
        w = ('Saturday')
    elif h==1:
        w = ('Sunday')
    elif h==2:
        w = ('Monday')
    elif h==3:
        w = ('Tuesday')
    elif h==4:
        w = ('Wednesday')
    elif h==5:
        w = ('Thursday')
    elif h==6:
        w = ('Friday')
        
    print("Day of the Week is",w)
    
elif m==2:
    m+= 12
    k = k-1
    h = int(((q + ((26*(m+1))/10) + k + (k/4) + (j/4) + (5*j))%7))
    if h==0:
        w = ('Saturday')
    elif h==1:
        w = ('Sunday')
    elif h==2:
        w = ('Monday')
    elif h==3:
        w = ('Tuesday')
    elif h==4:
        w = ('Wednesday')
    elif h==5:
        w = ('Thursday')
    elif h==6:
        w = ('Friday')
        
    print("Day of the Week is",w)

else:
    h = int(((q + ((26*(m+1))/10) + k + (k/4) + (j/4) + (5*j))%7))
    if h==0:
        w = ('Saturday')
    elif h==1:
        w = ('Sunday')
    elif h==2:
        w = ('Monday')
    elif h==3:
        w = ('Tuesday')
    elif h==4:
        w = ('Wednesday')
    elif h==5:
        w = ('Thursday')
    elif h==6:
        w = ('Friday')
        
    print("Day of the Week is",w)