'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 3 Question 19
## Program to draw line and write coordinates

import turtle

x1,y1 = eval(input("Enter coordinates for first point: "))
x2,y2 = eval(input("Enter coordinates for second point: "))

turtle.penup()
turtle.goto(x1,y1)
turtle.write((x1,y1), font=("Arial",
8, "normal"))
turtle.color("red")
turtle.pendown()
turtle.goto(x2,y2)
turtle.write((x2,y2), font=("Arial",
8, "normal"))
turtle.hideturtle()
turtle.done()