### Chapter 3 Question 3
## Program to find Area enclosed by the city

from math import radians
from numpy import arccos
from cmath import sin
from cmath import cos

r = 6371.01
x1 = radians(33.7489954)
y1 = radians(-84.3879824)
x2 = radians(28.5383355)
y2 = radians(-81.37923649999999)
x3 = radians(32.0835407)
y3 = radians(-81.09983419999998)
x4 = radians(35.2270869)
y4 = radians(-80.84312669999997)

s1 = abs((r * arccos(sin(x1)) * sin(x2)) + (cos(x1) * cos(x2) * cos(y1-y2)))

s2 = abs((r * arccos(sin(x2)) * sin(x3)) + (cos(x2) * cos(x2) * cos(y2-y3)))

s3 = abs((r * arccos(sin(x3)) * sin(x4)) + (cos(x3) * cos(x4) * cos(y3-y4)))

s4 = abs((r * arccos(sin(x4)) * sin(x1)) + (cos(x4) * cos(x1) * cos(y4-y1)))

d = abs((r * arccos(sin(x1)) * sin(x3)) + (cos(x1) * cos(x3) * cos(y1-y3)))

print("Distance between Atlanta and Orlando is",s1,"km")
print("Distance between Orlando and Savannah is",s2,"km")
print("Distance between Savannah and Charlotte is",s3,"km")
print("Distance between Charlotte and Atlanta is",s4,"km")

sa = (s1+s2+d)/2
sb = (s3+s4+d)/2

A1 = (sa*(sa-s1)*(sa-s2)*(sa-d))**0.5
A2 = (sb*(sb-s3)*(sb-s4)*(sb-d))**0.5

A = A1 + A2

print("Area enclosed by the cities is",A,"km")