'''
Created on Feb 5, 2017

@author: pande
'''
### Chapter 6 Question 10
## Program to print 1000 prime numbers

def isPrime(n):
    i = 2
    while i<= n/2:
        if n%i == 0:
            return False
        i += 1
    return True

def palindrome(n):
    reverse = 0
    temp = n
    while n>0:
        reverse = reverse*10
        reverse = reverse + n%10
        n = n//10
    if temp == reverse:
        return True
    else:
        return False

def printPrimeNumbers(num):
    line = eval(input("How many numbers you want to print per line?: "))
    count = 0
    n = 2
    while count<num:
        if isPrime(n):
            if palindrome(n):
                count += 1
                print(format(n,"5d"),end="     ")
                if count % line == 0:
                    print()
        n += 1
def main():
    num = eval(input("How many Prime numbers do you want to print?: "))
    printPrimeNumbers(num)
main()